# Pac-Man
Pac-Man game written in HTML5 + CSS3 + jQuery with Canvas. This WebApp is a Responsive Web Design (RWD) website.

<a href="https://pacman-e281c.firebaseapp.com">Play game</a>
